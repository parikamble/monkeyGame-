var survivalTime=0
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
 // creating monkey
  monkey=createSprite(80,315,20,20);
  monkey.addAnimation("moving", monkey_running);
  monkey.scale=0.1;
     
  
  ground=createSprite(400,350,900,10);
  ground.velocityX=-4;
  ground.x=ground.width/2;
  console.log(ground.x);
  
  
  
  
}


function draw() {

  background(255);
  
  if (ground.x) {
  ground.x=ground.width/2;
  
  }
   
  if(keyDown("space")&& monkey.y >= 100) {
       
    
    monkey.velocityY= -12;
    
  }
  //add gravity
  monkey.velocityY= monkey.velocityY= +8;
  
  monkey.collide(ground);
  
  
  
  stroke("white") ;       
  textSize(20);
  fill("white")
  
   stroke("black") ;       
  textSize(20);
  fill("black")
  survivalTime=Math.ceil(frameCount/frameRate())
  text("survival Time: " +survivalTime, 100,50)
  
  
  
  
  drawSprites();
  
}

function food(){
 if (frameCount % 60 === 0){
   var banana = createSprite(600,165,10,40);
   sprite.velocityX = -(6 + score/100);
   
    //generate random obstacles
    var rand = Math.round(random(1,6));
    switch(rand) {
      case 1: sprite.addImage(sprite1);
              break;
      case 2: sprite.addImage(sprite2);
              break;
      case 3: sprite.addImage(sprite3);
              break;
      case 4: sprite.addImage(sprite4);
              break;
      case 5: sprite.addImage(sprite5);
              break;
      case 6: sprite.addImage(sprite6);
              break;
      case 7: sprite.addImage(sprite7);  
              break;
      case 8: sprite.addImage(sprite8);  
              break;        
     default: break;
    }
   
    //assign scale and lifetime to the obstacle           
    sprite.scale = 0.5;
    sprite.lifetime = 200;
   
   //add each obstacle to the group
    obstaclesGroup.add(obstacle);
 }
}

